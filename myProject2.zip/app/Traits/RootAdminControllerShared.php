<?php
namespace App\Traits;

trait RootAdminControllerShared
{
    public $appId = 5;
}