<?php
namespace App\Traits;

trait StoresControllerShared
{
    public $appId = 2;
}