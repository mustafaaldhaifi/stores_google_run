<?php
namespace App\Traits;

trait DeliveryControllerShared
{
    public $appId = 3;
}