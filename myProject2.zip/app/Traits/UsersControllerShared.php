<?php
namespace App\Traits;

trait UsersControllerShared
{
    
    use AllShared;
    // public function getMyApp(Request $request)
    // {
    //     $sha = $request->input('sha');
    //     $packageName = $request->input('packageName');

    //     // 
    //     $app = DB::table(Apps::$tableName)
    //         ->where(Apps::$sha, $sha)
    //         ->where(Apps::$packageName, $packageName)
    //         ->sole([
    //             Apps::$tableName . '.' . Apps::$id 
    //         ]);
    //      return $app;
    // }
}