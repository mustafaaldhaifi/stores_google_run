<?php

namespace App\Models;

class ProductImages
{
   public static $tableName = "productImages";
   public static $id = "id";
   public static $image = "image";
   public static $productId = "productId";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
