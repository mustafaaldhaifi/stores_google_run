<?php

namespace App\Models;

class StoreSections
{
   public static $tableName = "storeSections";
   public static $id = "id";
   public static $sectionId = "sectionId";
   public static $storeCategoryId = "storeCategoryId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
