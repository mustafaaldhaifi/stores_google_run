<?php

namespace App\Models;

class OrderStatus
{
   public static $tableName = "orderStatus";
   public static $id = "id";
   public static $situationId = "situationId";
   public static $orderId = "orderId";
   public static $createdAt = "createdAt";
}
