<?php

namespace App\Models;

class WhatsappMessages
{
   public static $tableName = "whatsappMessages";
   public static $id = "id";
   public static $message = "message";
   public static $messageId = "messageId";
   public static $sevicesMode = "sevicesMode";
   public static $userId = "userId";

   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
