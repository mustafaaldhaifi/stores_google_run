<?php

namespace App\Models;

class OrdersPayments
{
   public static $tableName = "ordersPayments";
   public static $id = "id";
   public static $orderId = "orderId";
   public static $paymentId = "paymentId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
