<?php

namespace App\Models;

class OrderSituations
{
   public static $tableName = "orderSituations";
   public static $id = "id";
   public static $name = "name";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
