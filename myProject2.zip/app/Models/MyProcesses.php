<?php

namespace App\Models;

class MyProcesses
{
   public static $tableName = "myProcesses";
   public static $id = "id";
   public static $name = "name";
   public static $countFail5m = "countFail5m";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
