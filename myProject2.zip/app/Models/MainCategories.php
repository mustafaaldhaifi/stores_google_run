<?php

namespace App\Models;

class MainCategories
{
   public static $tableName = "mainCategories";
   public static $id = "id";
   public static $name = "name";
   public static $image = "image";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
