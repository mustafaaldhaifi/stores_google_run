<?php

namespace App\Models;

class Configuration
{
   public static $tableName = "configuration";
   public static $id = "id";
   public static $remoteConfigVersion = "remoteConfigVersion";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
