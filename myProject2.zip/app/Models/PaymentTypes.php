<?php

namespace App\Models;

class PaymentTypes
{
   public static $tableName = "paymentTypes";
   public static $id = "id";
   public static $name = "name";
   public static $image = "image";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
