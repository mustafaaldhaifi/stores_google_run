<?php

namespace App\Models;

class SharedableStores
{
   public static $tableName = "sharedableStores";
   public static $id = "id";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
}
