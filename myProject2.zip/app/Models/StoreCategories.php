<?php

namespace App\Models;

class StoreCategories
{
   public static $tableName = "storeCategories";
   public static $id = "id";
   public static $storeId = "storeId";
   public static $categoryId = "categoryId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
