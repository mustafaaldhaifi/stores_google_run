<?php

namespace App\Models;

class ProductViews
{
   public static $tableName = "productViews";
   public static $id = "id";
   public static $name = "name";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
