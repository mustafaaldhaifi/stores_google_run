<?php

namespace App\Models;

class InAppProducts
{
   public static $tableName = "inAppProducts";
   public static $id = "id";
   public static $name = "name";
   public static $points = "points";
   public static $isSubs = "isSubs";
   public static $productId = "productId";
   public static $createdAt = "createdAt";
}
