<?php

namespace App\Models;

class Locations
{
   public static $tableName = "locations";
   public static $id = "id";
   public static $street = "street";
   public static $latLng = "latLng";
   public static $userId = "userId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
