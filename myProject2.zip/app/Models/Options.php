<?php

namespace App\Models;

class Options
{
   public static $tableName = "options";
   public static $id = "id";
   public static $name = "name";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
