<?php

namespace App\Models;

class StoresTime
{
   public static $tableName = "storesTime";
   public static $id = "id";
   public static $openAt = "openAt";
   public static $closeAt = "closeAt";
   public static $day = "day";
   public static $storeId = "storeId";
   public static $isOpen = "isOpen";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
