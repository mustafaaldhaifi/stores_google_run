<?php

namespace App\Models;

class StorePaymentTypes
{
   public static $tableName = "storePaymentTypes";
   public static $id = "id";
   public static $storeId = "storeId";
   public static $paymentTypeId = "paymentTypeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
