<?php

namespace App\Models;

class StoreNestedSections
{
   public static $tableName = "storeNestedSections";
   public static $id = "id";
   public static $storeSectionId = "storeSectionId";
   public static $nestedSectionId = "nestedSectionId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
