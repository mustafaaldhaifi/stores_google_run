<?php

namespace App\Models;

class Youtube
{
   public static $tableName = "youtube";
   public static $id = "id";
   public static $isReels = "isReels";
   public static $image = "image";
   public static $url = "url";
   public static $order = "order";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
