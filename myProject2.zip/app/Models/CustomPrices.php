<?php

namespace App\Models;

class CustomPrices
{
   public static $tableName = "customPrices";
   public static $id = "id";
   public static $storeProductId = "storeProductId";
   public static $price = "price";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
