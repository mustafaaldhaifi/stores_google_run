<?php

namespace App\Models;

class Currencies
{
   public static $tableName = "currencies";
   public static $id = "id";
   public static $name = "name";
   public static $sign = "sign";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
