<?php

namespace App\Models;

class DeliveryMen
{
   public static $tableName = "deliveryMen";
   public static $id = "id";
   public static $userId = "userId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
