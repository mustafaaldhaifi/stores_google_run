<?php

namespace App\Models;

class Languages
{
   public static $tableName = "languages";
   public static $id = "id";
   public static $code = "code";
   public static $name = "name";
   public static $createdAt = "createdAt";
   // public static $updatedAt = "updatedAt";

}
