<?php

namespace App\Models;

class StoreInfo
{
   public static $tableName = "storeInfo";
   public static $id = "id";
   public static $call = "call";
   public static $facebook = "facebook";
   public static $x = "x";
   public static $instagram = "instagram";
   public static $storeId = "storeId";
   public static $whatsapp = "whatsapp";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
