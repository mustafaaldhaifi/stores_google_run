<?php

namespace App\Models;

class Situations
{
   public static $VIEWD = 4;
   public static $NEW = 1;
   public static $COMPLETED = 2;
   public static $CENCELED = 3;
   public static $ASSIGN_DELIVERY_MAN = 5;
   public static $PREPARING = 6;
   public static $AT_WAY = 7;
}
