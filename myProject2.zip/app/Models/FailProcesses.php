<?php

namespace App\Models;

class FailProcesses
{
   public static $tableName = "failProcesses";
   public static $id = "id";
   public static $myProcessId = "myProcessId";
   public static $deviceId = "deviceId";
   public static $userId = "userId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
