<?php

namespace App\Models;

class Devices
{
   public static $tableName = "devices";
   public static $id = "id";
   public static $deviceId = "deviceId";
   public static $model = "model";
   public static $version = "version";
   public static $createdAt = "createdAt";
}
