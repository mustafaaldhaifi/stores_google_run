<?php

namespace App\Models;

class DevicesSessions
{
   public static $tableName = "devicesSessions";
   public static $id = "id";
   public static $deviceId = "deviceId";
   public static $appId = "appId";
   public static $appToken = "appToken";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";

}
