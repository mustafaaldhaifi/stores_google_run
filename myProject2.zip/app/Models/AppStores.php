<?php

namespace App\Models;

class AppStores
{
   public static $tableName = "appStores";
   public static $id = "id";
   public static $appId = "appId";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
}
