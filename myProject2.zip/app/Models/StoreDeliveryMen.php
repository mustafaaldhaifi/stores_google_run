<?php

namespace App\Models;

class StoreDeliveryMen
{
   public static $tableName = "storeDeliveryMen";
   public static $id = "id";
   public static $deliveryManId = "deliveryManId";
   public static $storeId = "storeId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
