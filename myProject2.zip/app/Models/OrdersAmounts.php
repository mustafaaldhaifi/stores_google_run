<?php

namespace App\Models;

class OrdersAmounts
{
   public static $tableName = "ordersAmounts";
   public static $id = "id";
   public static $orderId = "orderId";
   public static $amount = "amount";
   public static $currencyId = "currencyId";
   public static $createdAt = "createdAt";
   public static $updatedAt = "updatedAt";
}
