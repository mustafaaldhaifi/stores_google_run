<?php

trait StoreManagerGet
{

}